Journal of the Audio Engineering Society
------------------------------------------

The following files are available in jaes.zip archive:

aes2e.cls    - This is the updated class file - 2025 - for the jaes template
jaes.cls    - This is the LaTeX2e class file for jaes template
jaes-guide.pdf  - This is PDF of Author Guide for jaes template
jaes-sample1-bibtex.pdf  - This is PDF file of sample LaTeX document for jaes template 1
jaes-sample1-bibtex.tex  - LaTeX document of sample 1, which uses references taken from the BibTex library
jaes-sample2-bibitem.pdf  - This is PDF file of sample LaTeX document for jaes template 2
jaes-sample2-bibitem.tex  - LaTeX document of sample 2 in which references are edited at the end of the file as bibitems
jaes-mouse.eps   - Graphics file used in sample
jaes.bib    - bibTex library used in the sample
jaes.bst    - bibTex style file used in the sample
cuted.sty   - This is the LaTeX2e style file for jaes template

Please use jaes-sample1-bibtex.tex or jaes-sample2-bibitem.tex as the template for your JAES paper. 
Happy TeXing!!!

Kurt James Werner and Vesa Välimäki
